  //	EndlessWepMenu v1.0   //
 //		AUTHOR: Indy		 //
//////////////////////////////

Endless Weapons Menu Plugin for CoDaM
Author: Indy
Tested with CoDaM v1.3+ and CoD 1.1

Description: This plugin will allow players to select the enabled weapons from both allies and axis teams.

INSTALLATION
============
	TO INSTALL: * Place ___CoDaM_EndlessMenu.pk3 in server's MAIN folder
				* Add the following to your codam\modlist.gsc: 
					[[ register ]]( "Endless Weapons Menu", codam\menu_weps::main); 
				* Add the following cvar to your server.cfg:
					set endless_wepmenu 1