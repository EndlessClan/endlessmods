  //	EndlessPAM v1.0   //
 //////////////////////////////

EndlessPAM for CoD1.1
Original Author: Garet (Project Ares Mod)
Backported by: Indy (with PAMv1.08)

Tested with CoDaM v1.3+, CoDaM HamGoodies, CoDaM Powerserver and CoD 1.1

Description: The original PAM from 1.5 backported to 1.1 with the same functionalities and usability with CoDaM mods. 
 
    		 Powerserver commands -> Added 
			 CoDaM commands -> Works (most do, unless modified by PAM)
			 HamGoodies commands -> Works
			 
Reference Guide (Highly Recommended): http://www.anarchyrules.co.uk/cod/CoD_PAM_Reference_Guide.htm

*NOTE: EndlessPAM uses different gametype to run PAM. Make sure to edit maprotation with "pam" for a PAM server NOT "sd"
** NOT THOROUGHLY TESTED- MAY HAVE BUGS -CONTACT IF THATS THE CASE

INSTALLATION
============
	TO INSTALL: * Place z_svr_pamv108.pk3 and pam.cfg in server's MAIN folder
				* Add the following to your dedicated.cfg or myserver.cfg: 
					exec pam.cfg
				* Edit the cvars in pam.cfg with desired settings
				* Modify sv_maprotation to change gametype to "pam" on map_rotate instead of "sd"