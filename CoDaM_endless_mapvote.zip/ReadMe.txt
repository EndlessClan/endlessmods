  //	EndlessMapvote v1.0   //
 //		AUTHOR: Indy		 //
//////////////////////////////

Endless Mapvote for CoDaM
Author: Indy
Requirements: CoDaM Powerserver Plugin
Tested with CoDaM v1.3+ and CoD 1.1

Description: This plugin will allow players to vote for the next map or gametype at the end of the map based on the server's maprotation.

INSTALLATION
============
	TO INSTALL: * Place ___CoDaM_EndlessMapVote.pk3 in server's MAIN folder
				* Add the following to your codam\modlist.gsc: 
					[[ register ]]( "Endless Mapvote", codam\endless_mapvote::main);
				* Edit the following cvar in CoDaM_PowerServer.cfg with desired value:
					set psv_mapvote_time "30" 
				* Edit the following cvar in CoDaM_Powerserver.cfg with desired maps and gametypes:
					set psv_mapvote_rotation "gametype sd map mp_harbor gametype dm map mp_carentan gametype tdm map mp_railyard"